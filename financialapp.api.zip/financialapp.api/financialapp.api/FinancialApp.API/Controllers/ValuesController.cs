﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FinancialApp.Data;

namespace FinancialApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly FinancialAppContext db;

        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            try { 
                var lst = db.Account.ToList();
                return Ok(lst);
            }
            catch {
                return BadRequest();
            }
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<FinancialApp.Data.Entities.Account> Get(int id)
        {
            try 
            { 
                var found = db.Account.Where(x=> x.Id == id).ToList();
                return Ok(found);
            }
            catch
            {
                return BadRequest();
            }
        }
   
    }
}
